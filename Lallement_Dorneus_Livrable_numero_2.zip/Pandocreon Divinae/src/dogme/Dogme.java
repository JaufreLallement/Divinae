/**
 * 
 */
package dogme;

/**
 * @author Lallement
 * La classe dogme d�crit les dogmes adopt�s par certaines cartes.
 */
public enum Dogme {
	NATURE,
	HUMAIN,
	SYMBOLES,
	MYSTIQUES,
	CHAOS
}
