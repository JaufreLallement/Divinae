/**
 * 
 */
package effets;

/**
 * @author Lallement
 * 
 */
public interface Effet {
	/**
	 * M�thode permettant � une carte divinit� d'activer son effet sp�cial
	 */
	public void appliquerEffet();
}
