/**
 * 
 */
package strategie;

/**
 * @author Lallement
 *
 */
public class StrategiePassive implements Strategy {

	/**
	 * Constructeur par d�faut
	 */
	public StrategiePassive() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Impl�mentation de la m�thode jouer
	 * @see strategie.Strategy#jouer()
	 */
	@Override
	public void jouer() {
		// TODO Auto-generated method stub

	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
