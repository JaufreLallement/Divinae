/**
 * 
 */
package strategie;

/**
 * @author Lallement
 *
 */
public interface Strategy {
	
	/**
	 * M�thode permettant � un joueur virtuel de jouer en employant une strategie pr�cise
	 */
	public void jouer();
}
